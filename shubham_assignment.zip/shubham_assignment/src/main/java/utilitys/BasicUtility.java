package utilitys;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasicUtility {
	WebDriver driver;
	public WebDriver startUp(String bname, String url) {
		String path = System.getProperty("user.dir");

		if (bname.equalsIgnoreCase("CH") || bname.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", path + "\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
		}

		else if (bname.equalsIgnoreCase("FF") || bname.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", path + "\\drivers\\geckodriver.exe");
			driver = new FirefoxDriver();
		}

		else if (bname.equalsIgnoreCase("edge")) {
			System.setProperty("webdriver.edge.driver", path + "\\drivers\\msedgedriver.exe");
			driver = new EdgeDriver();
		}
		else {
			System.out.println("Enter valid browser Name !!!!");
		}
		
		driver.manage().window().maximize();
		//driver.manage().window().minimize(); // selenium 4 feature
		//driver.manage().window().setSize(new Dimension (600, 600));
         driver.get(url);
		return driver;
	}
	
	public void waitForVisibilityOfWebelement(WebDriver driver,WebElement ele, int time) {
		WebDriverWait wt = new WebDriverWait(driver, Duration.ofSeconds(time));
		wt.until(ExpectedConditions.visibilityOf(ele));
	}


	public void waitForVisibilityOfLocator(WebDriver driver,String Locatortype
			,String Locatorsyntax, int time){
		WebDriverWait wt = new WebDriverWait(driver,Duration.ofSeconds(time) );
		switch (Locatortype) {
		case "xpath": wt.until(ExpectedConditions.visibilityOfElementLocated
				(By.xpath(Locatorsyntax)));
		break;
		case "css": wt.until(ExpectedConditions.visibilityOfElementLocated
				(By.cssSelector(Locatorsyntax)));
		break;
		case "id": wt.until(ExpectedConditions.visibilityOfElementLocated
				(By.id(Locatorsyntax)));
		break;
		case "class": wt.until(ExpectedConditions.visibilityOfElementLocated
				(By.className(Locatorsyntax)));
		break;
		case "name" : wt.until(ExpectedConditions.visibilityOfElementLocated
				(By.name(Locatorsyntax)));
		break;
		default : System.out.println("invalid locator type ") ;
		}

	}
	
	public void waitForelementToBeClickableWebelement(WebDriver driver,WebElement ele, int time) {
		WebDriverWait wt = new WebDriverWait(driver, Duration.ofSeconds(time));
		wt.until(ExpectedConditions.elementToBeClickable(ele));
	}
	
	public void waitForelementToBeClickableLocator(WebDriver driver, String LocatorTyp,
			String LocatorSyntax, int time) {
		WebDriverWait wt = new WebDriverWait(driver, Duration.ofSeconds(time));
		switch(LocatorTyp) {
		
		case "xpath" : wt.until(ExpectedConditions.elementToBeClickable
				(By.xpath(LocatorSyntax)));
		break;
		
		case "id" : wt.until(ExpectedConditions.elementToBeClickable
				(By.id(LocatorSyntax)));
		break;
		
		case "name" : wt.until(ExpectedConditions.elementToBeClickable
				(By.name(LocatorSyntax)));
		break;
		
		case "css" : wt.until(ExpectedConditions.elementToBeClickable
				(By.cssSelector(LocatorSyntax)));
		break;
		
		case "class" : wt.until(ExpectedConditions.elementToBeClickable
				(By.className(LocatorSyntax)));
		break;
		
		default : System.out.println("invalid locator type ") ;
		}
	}
	
//	public void wait(WebDriver driver,WebElement ele, int time) {
//		WebDriverWait wt = new WebDriverWait(driver, Duration.ofSeconds(time));
//		wt.until(ExpectedConditions.);
//	}
	
	
	public void waitForpresenceOfElementLocated(WebDriver driver, String LocatorTyp,
			String LocatorSyntax, int time) {
		WebDriverWait wt = new WebDriverWait(driver, Duration.ofSeconds(time));
		switch(LocatorTyp) {
		
		case "xpath" : wt.until(ExpectedConditions.presenceOfElementLocated
				(By.xpath(LocatorSyntax)));
		break;
		
		case "id" : wt.until(ExpectedConditions.presenceOfElementLocated
				(By.id(LocatorSyntax)));
		break;
		
		case "name" : wt.until(ExpectedConditions.presenceOfElementLocated
				(By.name(LocatorSyntax)));
		break;
		
		case "css" : wt.until(ExpectedConditions.presenceOfElementLocated
				(By.cssSelector(LocatorSyntax)));
		break;
		
		case "class" : wt.until(ExpectedConditions.presenceOfElementLocated
				(By.className(LocatorSyntax)));
		break;
		
		default : System.out.println("invalid locator type ") ;
		}
	}
	
	public void scrollTillElement (WebElement ele, WebDriver driver) {
	    JavascriptExecutor js = (JavascriptExecutor)driver;
	    js.executeScript("arguments[0].scrollIntoView(true)", ele);
	}

	public void clickByJS(WebElement ele, WebDriver driver){
	    JavascriptExecutor js = (JavascriptExecutor)driver;
	    js.executeScript("arguments[0].click();", ele);
	}
	
	public boolean isAlertPresent(WebDriver driver, int time) {
		try {
	    WebDriverWait wt = new WebDriverWait(driver, Duration.ofSeconds(time));
	    wt.until(ExpectedConditions.alertIsPresent());
	    return true;
		}
		catch(Exception e) {
			return false;
		}

	}
	
	
	
	
	
}