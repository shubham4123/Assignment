package pages;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HomePage {
	
private WebDriver driver;
	
	@FindBy(id="sorter")
	private WebElement sort;
	
	@FindBy(className ="special-price")
	private WebElement  priceSort;
	
	@FindBy(className="product-item-link")
	private WebElement nameSort;



public HomePage (WebDriver driver)	//constructor
{
	this.driver = driver;
	PageFactory.initElements(driver,this);
	
	
}

 public void nameSort() {
	 
	 sort.click();
	 
	 Select sel = new Select(sort);
	 sel.selectByValue("name");
	 
	
	 List<WebElement> list =  driver.findElements(By.className("product-item-link"));
	 ArrayList<String> name = new ArrayList<String>();
	 
	  for(int i=0; i<list.size(); i++) {
		  name.add(list.get(i).getText());
	  }
	  
	  ArrayList<String> nameCopy = new ArrayList<String>();
	  nameCopy = name;
	 
	  Collections.sort(nameCopy);
	  
	  Assert.assertEquals(name, nameCopy);
	  
	 
 }
public void priceSort() {
	 
	 sort.click();
	 
	 Select sel = new Select(sort);
	 sel.selectByValue("price");
	 
	
	 List<WebElement> list =  driver.findElements(By.className("special-price"));
	 ArrayList<String> price = new ArrayList<String>();
	 
	  for(int i=0; i<list.size(); i++) {
		  price.add(list.get(i).getText());
	  }
	  
	  ArrayList<String> priceCopy = new ArrayList<String>();
	  priceCopy = price;
	 
	  Collections.sort(priceCopy);
	  
	  Assert.assertEquals(price, priceCopy);
	  
	 
 }

public void RefreshPage() {
	driver.get("https://shop.schneider-electric.co.in/shop-by-category/ups-and-stabilizers.html");
}



}
