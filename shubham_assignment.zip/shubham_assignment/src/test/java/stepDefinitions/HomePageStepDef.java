package stepDefinitions;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pages.HomePage;
import utilitys.BasicUtility;


class HomePageStepDef extends HomePage{
    
	//private HomePage lp = new HomePage());
	
	public HomePageStepDef(WebDriver driver) {
		super(driver);
	}

	@Given("User is on home page")
	public void user_is_on_home_page() {
		BasicUtility bs = new BasicUtility();
		String url = "https://shop.schneider-electric.co.in/shop-by-category/ups-and-stabilizers.html";
		bs.startUp("ch", url);	   
	}

	@Then("Product name should be in asscending desending order")
	public void product_name_should_be_in_asscending_desending_order() {
		nameSort();   
	}

	@Given("User is on the home page")
	public void user_is_on_the_home_page() {
		RefreshPage();
	}

	@Then("Product price should be in asscending desending order")
	public void product_price_should_be_in_asscending_desending_order() {
		priceSort();   
	}
}